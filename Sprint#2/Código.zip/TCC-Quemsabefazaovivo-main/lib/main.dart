import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:walkwithwoofs/views/users/forgotpass.dart';
import 'package:walkwithwoofs/views/users/login.dart';
import 'package:walkwithwoofs/views/pets/pet.dart';
import 'package:walkwithwoofs/views/users/profile.dart';
import 'package:walkwithwoofs/views/users/signup.dart';
import 'package:walkwithwoofs/views/home.dart';
import 'package:walkwithwoofs/views/flutter_chat_ui.dart';
import 'package:walkwithwoofs/views/maps.dart';
import 'package:walkwithwoofs/views/challenges.dart';
import 'firebase_options.dart';

Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  print("Mensagem chegando ${message.messageId}");
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => ThemeProvider(),
      child: Consumer<ThemeProvider>(
        builder: (context, themeProvider, child) {
          return MaterialApp(
            title: 'WalkWithWoofs',
            theme: ThemeData.light(),
            darkTheme: ThemeData.dark(),
            themeMode: themeProvider.themeMode,
            initialRoute: '/login',
            onGenerateRoute: (settings) {
              switch (settings.name) {
                case '/login':
                  return MaterialPageRoute(builder: (_) => LoginPage());
                case '/signup':
                  return MaterialPageRoute(builder: (_) => RegisterPage());
                case '/forgotpass':
                  return MaterialPageRoute(builder: (_) => ForgotpassPage());
                case '/home':
                  return MaterialPageRoute(builder: (_) => HomePage());
                case '/profile':
                  return MaterialPageRoute(builder: (_) => ProfilePage());
                case '/chat':
                  final chatId = settings.arguments as String?;
                  return MaterialPageRoute(
                      builder: (_) => ChatPage(chatId: chatId ?? ''));
                case '/maps':
                  return MaterialPageRoute(builder: (_) => MapPage());
                case '/challenges':
                  return MaterialPageRoute(
                      builder: (_) => ChallengesListPage());
                case '/pets':
                  return MaterialPageRoute(builder: (_) => PetPage());
                default:
                  return MaterialPageRoute(builder: (_) => LoginPage());
              }
            },
          );
        },
      ),
    );
  }
}

class ThemeProvider with ChangeNotifier {
  ThemeMode _themeMode = ThemeMode.system;

  ThemeMode get themeMode => _themeMode;

  void toggleTheme(bool isOn) {
    _themeMode = isOn ? ThemeMode.dark : ThemeMode.light;
    notifyListeners();
  }
}
