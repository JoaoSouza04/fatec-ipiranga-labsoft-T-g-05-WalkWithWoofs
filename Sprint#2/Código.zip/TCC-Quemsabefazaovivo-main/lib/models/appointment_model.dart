import 'package:flutter/material.dart';

class Appointment {
  final DateTime startTime;
  final DateTime endTime;
  final String subject;
  final String userId;

  Appointment({
    required this.startTime, 
    required this.endTime,
    required this.subject,
    required this.userId
  });

  Map<String, dynamic> toMap() {
    return {
      'startTime': startTime,
      'endTime': endTime,
      'subject': subject,
      'userId': userId
    };
  }

  Appointment.fromMap(Map<String, dynamic> map)
    : startTime = map['startTime'],
      endTime = map['endTime'],
      subject = map['subject'],
      userId = map['userId'];
}