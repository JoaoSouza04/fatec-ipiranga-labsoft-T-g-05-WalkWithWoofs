class Review {
  final String reviewerId;
  final String walkerId;
  final double rating;
  final String comment;

  Review(
      {required this.reviewerId, required this.walkerId, required this.rating,
        required this.comment});

  Map<String, dynamic> toMap() {
    return {
      'reviewerId': reviewerId,
      'walkerId': walkerId,
      'rating': rating,
      'comment': comment,
    };
  }

  Review.fromMap(Map<String, dynamic> map)
      : reviewerId = map['reviewerId'],
        walkerId = map['walkerId'],
        rating = map['rating'],
        comment = map['comment'];

}