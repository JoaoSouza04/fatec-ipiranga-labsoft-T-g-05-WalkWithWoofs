import 'package:cloud_firestore/cloud_firestore.dart';

class Challenge {
  String id;
  String title;
  String description;
  String reward;
  bool isActive;
  DateTime startDate;
  DateTime endDate;

    Challenge({
      required this.id,
      required this.title,
      required this.description,
      required this.reward,
      required this.isActive,
      required this.startDate,
      required this.endDate,
  });

  factory Challenge.fromMap(Map<String, dynamic> data, String documentId){
    return Challenge(
        id: documentId,
        title: data['title'] ?? '',
        description: data['description'] ?? '',
        reward: data['reward'] ?? '',
        isActive: data['isActive'] ?? '',
        startDate: (data['startDate'] as Timestamp).toDate(),
        endDate: (data['endDate'] as Timestamp).toDate(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'reward': reward,
      'isActive': isActive,
      'startDate': startDate,
      'endDate': endDate,
    };
  }
}