import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:walkwithwoofs/models/challenge_model.dart';

class ChallengeService {
  final CollectionReference _challengeCollection = FirebaseFirestore.instance.collection('challenges');

  Future<void> addChallenge(Challenge challenge) {
    return _challengeCollection.add(challenge.toMap());
  }

  Future<void> updateChallenge(Challenge challenge) {
    return _challengeCollection.doc(challenge.id).update(challenge.toMap());
  }

  Future<void> deleteChallenge(Challenge challenge) {
    return _challengeCollection.doc(challenge.id).delete();
  }

  Stream<List<Challenge>> getChallenges() {
    return _challengeCollection.snapshots().map((snapshot) {
      return snapshot.docs
          .map((doc) => Challenge.fromMap(doc.data() as Map<String, dynamic>, doc.id))
          .toList();
    });
  }

  Future<void> participateInChallenge(String challengeId, String userId) async {
    try {
      final DocumentReference challengeDoc = _challengeCollection.doc(challengeId);

      await FirebaseFirestore.instance.runTransaction((transaction) async {
        final DocumentSnapshot snapshot = await transaction.get(challengeDoc);

        if (!snapshot.exists) {
          throw Exception("Challenge does not exist!");
        }

        List participants = snapshot['participants'] ?? [];

        if (participants.contains(userId)) {
          throw Exception("User already in challenge!");
        }

        participants.add(userId);

        transaction.update(challengeDoc, {'participants': participants});
      });
    } catch(e){
      print('Error participating in challenge: $e');
      throw e;
    }
  }
}