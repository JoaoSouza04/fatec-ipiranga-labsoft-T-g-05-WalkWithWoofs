import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ReviewPage extends StatefulWidget {
  final String walkerId;

  ReviewPage({required this.walkerId});

  @override
  _ReviewPageState createState() => _ReviewPageState();
}

class _ReviewPageState extends State<ReviewPage> {
  final _formKey = GlobalKey<FormState>();
  double _rating = 0.0;
  String _comment = '';

  void _submitReview() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      try {
        await FirebaseFirestore.instance.collection('reviews').add({
          'reviewerId': FirebaseAuth.instance.currentUser!.uid,
          'walkerId': widget.walkerId,
          'rating': _rating,
          'comment': _comment,
        });
        Navigator.pop(context);
      } catch (e) {
        print(e);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text(
            'Avaliar Passeador',
            style: TextStyle(
              fontWeight: FontWeight.bold, 
            )
          ),
          centerTitle: true,
        ),
        body: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Form(
              key: _formKey,
              child: Column(
                children: <Widget>[
                  TextFormField(
                    decoration: InputDecoration(labelText: 'Comentario'),
                    maxLines: 3,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Por favor, digite palavras bonitas.';
                      }
                      return null;
                    },
                    onSaved: (value) => _comment = value!,
                  ),
                  SizedBox(height: 20),
                  Row(
                    children: <Widget>[
                      Text('Avaliaçao: '),
                      Expanded(
                        child: Slider(
                          value: _rating,
                          onChanged: (value) {
                            setState(() {
                              _rating = value;
                            });
                          },
                          min: 0,
                          max: 5,
                          divisions: 5,
                          label: '$_rating',
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: _submitReview,
                    child: Text('Enviar Avaliaçao'),
                  ),
                ],
              ),
            )));
  }
}
