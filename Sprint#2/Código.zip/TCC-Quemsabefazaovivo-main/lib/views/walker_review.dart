import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class WalkerReviewPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final userId = FirebaseAuth.instance.currentUser?.uid;

    if (userId == null) {
      return Scaffold(
        appBar: AppBar(
          title: Text(
            'Meus Reviews',
            style: TextStyle(
              fontWeight: FontWeight.bold, 
            )
          ),
        ),
        body: Center(
          child: Text('Usuario nao autenticado.'),
        ),
      );
    }
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Meus Reviews',
          style: TextStyle(
            fontWeight: FontWeight.bold, 
          )
        ),
        centerTitle: true,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('reviews')
            .where('walkerId', isEqualTo: userId)
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return Center(child: CircularProgressIndicator());
          }

          final reviews = snapshot.data!.docs;

          if (reviews.isEmpty) {
            return Center(child: Text('Nenhuma review encontrada.'));
          }

          return ListView.builder(
            itemCount: reviews.length,
            itemBuilder: (context, index) {
              final review = reviews[index].data() as Map<String, dynamic>;

              return Card(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                elevation: 5,
                margin: EdgeInsets.symmetric(vertical: 10, horizontal: 15),
                child: ListTile(
                  title: Text('Review ${index + 1}'),
                  subtitle: Text(review['comment'] ?? 'Oque disse amigo?'),
                  trailing: Text('Nota: ${review['rating' ?? '0']}'),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
