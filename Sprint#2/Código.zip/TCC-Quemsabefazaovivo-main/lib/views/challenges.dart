import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:walkwithwoofs/models/challenge_model.dart';
import 'package:walkwithwoofs/services/challenge_service.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';

class ChallengesListPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Desafios',
          style: TextStyle(
            fontWeight: FontWeight.bold, 
          )
        ),
        centerTitle: true,
      ),
      body: StreamProvider<List<Challenge>>.value(
        value: ChallengeService().getChallenges(),
        initialData: [],
        child: ChallengesListView(),
      ),
    );
  }
}

class ChallengesListView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final challenges = Provider.of<List<Challenge>>(context);

    if (challenges == null) {
      return Center(child: CircularProgressIndicator());
    }

    if (challenges.isEmpty) {
      return Center(child: Text('0 desafios disponiveis.'));
    }

    return AnimationLimiter(
        child: ListView.builder(
          itemCount: challenges.length,
          itemBuilder: (context, index) {
            final challenge = challenges[index];
            return AnimationConfiguration.staggeredList(
              position: index,
              duration: const Duration(milliseconds: 500),
              child: SlideAnimation(
                verticalOffset: 50.0,
                child: FadeInAnimation(
                  child: ChallengeTile(challenge: challenge),
                ),
              ),
            );
          },
        )
    );
  }
}

class ChallengeTile extends StatelessWidget {
  final Challenge challenge;

  const ChallengeTile({required this.challenge});

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      elevation: 5,
      margin: EdgeInsets.symmetric(vertical: 10, horizontal: 15),
      child: ListTile(
        contentPadding: EdgeInsets.all(15),
        title: Text(challenge.title,
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 5),
            Text(challenge.description),
            SizedBox(height: 10),
            Row(
              children: [
                Icon(Icons.card_giftcard, color: Colors.amber),
                SizedBox(width: 5),
                Expanded(child: Text(
                  'Recompensa: ${challenge.reward}',
                  style: TextStyle(fontWeight: FontWeight.w600),
                ),
                ),
              ],
            ),
            SizedBox(height: 10),
            Text('Inicio: ${formatDate(challenge.startDate)}',
              style: TextStyle(fontStyle: FontStyle.italic)),
            Text('Fim: ${formatDate(challenge.endDate)}',
                style: TextStyle(fontStyle: FontStyle.italic)),
          ],
        ),
        trailing: ElevatedButton(
          onPressed: () async {
            try {
              await ChallengeService().participateInChallenge(
                  challenge.id, FirebaseAuth.instance.currentUser!.uid);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Participando do desafio!!')),
              );
            } catch (e) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Erro ao participar: $e')),
              );
            }
          },
          child: Text('Participar'),
        ),
      ),
    );
  }
  String formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year} ${date.hour}:${date.minute}${date.second}';
  }
}