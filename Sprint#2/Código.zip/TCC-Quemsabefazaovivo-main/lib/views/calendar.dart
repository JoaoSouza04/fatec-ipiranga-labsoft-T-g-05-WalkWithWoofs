import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';

import '../models/appointment_model.dart';

class CalendarPage extends StatefulWidget {
  @override
  _CalendarPageState createState() => _CalendarPageState();
}

class _CalendarPageState extends State<CalendarPage> {
  final User? _user = FirebaseAuth.instance.currentUser;
  
  late List<String> _selectedEvents;
  
  late Appointment appointment;
  List<Appointment> _appointments = [];
  
  late TimeOfDay? startTime;
  late TimeOfDay? endTime;
  late String subject;
  
  late DateTime _selectedDay;
  late DateTime _focusedDay;

  late FirebaseFirestore _firestore;
  
  @override
  void initState() {
    super.initState();
    _selectedEvents = [];
    _selectedDay = DateTime.now();
    _focusedDay = DateTime.now();
    _firestore = FirebaseFirestore.instance;
    _loadAppointments();
  }

  Future<void> _loadAppointments() async {

    if(_user != null) {
      final QuerySnapshot snapshot = await _firestore.collection('appointments')
        .where('userId', isEqualTo: _user.uid)
        .get();
    
      final docs = snapshot.docs.map((doc) {
        final data = doc.data() as Map<String, dynamic>;
        return Appointment( 
          startTime: (data['startTime'] as Timestamp).toDate(), 
          endTime: (data['endTime'] as Timestamp).toDate(), 
          subject: data['subject'], 
          userId: data['userId']
        );
      }).toList();

      setState(() {
        _appointments = docs;
      });
    }
  }

  List<String> _getEventsForDay(DateTime day) {
    List<String> newEvents = [];
    final date = DateTime(day.year, day.month, day.day);
    for(var appointment in _appointments) {
      final appointmentDate = DateTime(
        appointment.startTime.year, 
        appointment.startTime.month, 
        appointment.startTime.day
      );
      if(appointmentDate == date) {
        newEvents.add(appointment.subject);
      }
    } 
    return newEvents;
  }

  void _addAppointment(Appointment appointment) async {
    
    if (_user != null) {
      final DocumentReference docRef = await _firestore.collection('appointments').add({
        'startTime': appointment.startTime,
        'endTime': appointment.endTime,
        'subject': appointment.subject,
        'userId': _user.uid,
      });

      setState(() {
        _appointments.add(appointment);
      });
    }
  }

  void getTime () async {
    startTime = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
      initialEntryMode: TimePickerEntryMode.input,
      builder: (BuildContext context, Widget? child) {
        return MediaQuery(
          data: MediaQuery.of(context).copyWith(alwaysUse24HourFormat: true),
          child: child!,
        );
      },
    );

    if (startTime == null) return;

    endTime = await showTimePicker(
      context: context,
      initialTime: startTime!.replacing(
        minute: startTime!.minute < 30 ? startTime!.minute + 30 : startTime!.minute + 15
      ),
      initialEntryMode: TimePickerEntryMode.input,
      builder: (BuildContext context, Widget? child) {
        return MediaQuery(
          data: MediaQuery.of(context).copyWith(alwaysUse24HourFormat: true),
          child: child!,
        );
      },
    );

    if (endTime == null) return;

    if((startTime!= null) && (endTime != null)) {
      appointment = Appointment(
        startTime: DateTime(_selectedDay.year, _selectedDay.month, _selectedDay.day, startTime!.hour - 3, startTime!.minute), 
        endTime: DateTime(_selectedDay.year, _selectedDay.month, _selectedDay.day, endTime!.hour - 3, endTime!.minute), 
        subject: subject, 
        userId: _user!.uid
      );
      _addAppointment(appointment);
    }

  }

  void _showAddEventDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Adicionar Evento'),
          content: TextField(
            onChanged: (value) {
              subject = value;
            },
            decoration: InputDecoration(hintText: 'Digite o evento'),
          ),
          actions: [
            TextButton(
              onPressed: () {
                if (subject.isNotEmpty) {
                  Navigator.pop(context);
                  getTime();
                }
              },
              child: Text('Adicionar'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancelar'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Calendário de Passeios',
          style: TextStyle(
            fontWeight: FontWeight.bold, 
          )
        ),
        centerTitle: true,
      ),
      body: Column(
        children: [
          TableCalendar(
            firstDay: DateTime.utc(2020, 1, 1),
            lastDay: DateTime.utc(2123, 12, 31),
            focusedDay: _focusedDay,
            selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
            onDaySelected: (selectedDay, focusedDay) {
              if (!isSameDay(_selectedDay, selectedDay)) {
                setState(() {
                  _selectedDay = selectedDay;
                  _focusedDay = focusedDay;
                  _selectedEvents = _getEventsForDay(selectedDay);
                });
              }
            },
            eventLoader: _getEventsForDay,
            startingDayOfWeek: StartingDayOfWeek.monday,
            calendarStyle: CalendarStyle(
              todayDecoration: BoxDecoration(
                color: Colors.blue,
                shape: BoxShape.circle,
              ),
              selectedDecoration: BoxDecoration(
                color: Colors.orange,
                shape: BoxShape.circle,
              ),
            ),
          ),
          SizedBox(height: 10.0),
          Expanded(
            child: ListView.builder(
              itemCount: _selectedEvents.length,
              itemBuilder: (context, index) {
                return Card(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  elevation: 5,
                  margin: EdgeInsets.symmetric(vertical: 10, horizontal: 15),
                  child: ListTile(
                    title: Text('Agendamento: ${_selectedEvents[index]}'),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    floatingActionButton: FloatingActionButton(
      onPressed: _showAddEventDialog,
      child: Icon(Icons.add),
      backgroundColor: Colors.lightBlue[900],
      foregroundColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(30.0),
      )
    ),
    );
  }

  String formatDate(DateTime date) {
    return 
    '${date.day}/${date.month}/${date.year} - ${date.hour}:${date.minute}';
  }
}