import 'package:flutter/material.dart';
import 'package:flutter_chat_ui/flutter_chat_ui.dart';
import 'package:flutter_chat_types/flutter_chat_types.dart' as types;
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

class ChatPage extends StatefulWidget {
  final String chatId;

  ChatPage({required this.chatId});

  @override
  _ChatPageState createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final _auth = FirebaseAuth.instance;
  late final _firestore = FirebaseFirestore.instance;
  late final types.User _user;
  late final types.User _otherUser;

  @override
  void initState() {
    super.initState();
    print('Chat ID: ${widget.chatId}');
    _user = types.User(
      id: _auth.currentUser!.uid,
      firstName: _auth.currentUser!.displayName ?? 'User',
    );
    _otherUser = types.User(id: 'Placeholder', firstName: 'Placeholder 2');
  }

  void _onSendPressed(types.PartialText message) async {
    final chatMessage = types.TextMessage(
      author: _user,
      createdAt: DateTime.now().millisecondsSinceEpoch,
      id: DateTime.now().toString(),
      text: message.text,
    );

    await _firestore
        .collection('chats')
        .doc(widget.chatId)
        .collection('messages')
        .add({
      'authorId': chatMessage.author.id,
      'createdAt': chatMessage.createdAt,
      'id': chatMessage.id,
      'text': chatMessage.text,
    });
  }

  void _onSendImagePressed(File imageFile) async {
    final chatMessage = types.ImageMessage(
      author: _user,
      createdAt: DateTime.now().millisecondsSinceEpoch,
      id: DateTime.now().toString(),
      name: imageFile.path.split('/').last,
      size: imageFile.lengthSync(),
      uri: imageFile.path,
    );

    await _firestore
        .collection('chats')
        .doc(widget.chatId)
        .collection('messages')
        .add({
      'authorId': chatMessage.author.id,
      'createdAt': chatMessage.createdAt,
      'id': chatMessage.id,
      'name': chatMessage.name,
      'size': chatMessage.size,
      'uri': chatMessage.uri,
      'type': 'image',
    });
  }

  void _onSendLinkPressed(String link) async {
    final chatMessage = types.TextMessage(
      author: _user,
      createdAt: DateTime.now().millisecondsSinceEpoch,
      id: DateTime.now().toString(),
      text: link,
    );

    await _firestore
        .collection('chats')
        .doc(widget.chatId)
        .collection('messages')
        .add({
      'authorId': chatMessage.author.id,
      'createdAt': chatMessage.createdAt,
      'id': chatMessage.id,
      'text': chatMessage.text,
      'type': 'link',
    });
  }

  Stream<List<types.Message>> _messageStream() {
    return _firestore
        .collection('chats')
        .doc(widget.chatId)
        .collection('messages')
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map(
          (snapshot) => snapshot.docs.map((doc) {
            final data = doc.data();
            if (data['type'] == 'image') {
              return types.ImageMessage(
                author: _user.id == data['authorId'] ? _user : _otherUser,
                createdAt: data['createdAt'],
                id: data['id'],
                name: data['name'],
                size: data['size'],
                uri: data['uri'],
              );
            } else {
              return types.TextMessage(
                author: _user.id == data['authorId'] ? _user : _otherUser,
                createdAt: data['createdAt'],
                id: data['id'],
                text: data['text'],
              );
            }
          }).toList(),
        );
  }

  Future<void> _pickImage() async {
    final pickedFile =
        await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      _onSendImagePressed(File(pickedFile.path));
    }
  }

  void _showSendLinkDialog() {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          String link = '';
          return AlertDialog(
            title: Text('Enviar Link'),
            content: TextField(
              onChanged: (value) {
                link = value;
              },
              decoration: InputDecoration(hintText: 'Digite o link'),
            ),
            actions: [
              TextButton(
                onPressed: () {
                  if (link.isNotEmpty) {
                    _onSendLinkPressed(link);
                    Navigator.of(context).pop();
                  }
                },
                child: Text('Enviar'),
              ),
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: Text('Cancelar'),
              ),
            ],
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Chat',
          style: TextStyle(
            fontWeight: FontWeight.bold, 
          )
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.image),
            onPressed: _pickImage,
          ),
          IconButton(
            icon: Icon(Icons.link),
            onPressed: _showSendLinkDialog,
          ),
        ],
      ),
      body: StreamBuilder<List<types.Message>>(
        stream: _messageStream(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('Erro: ${snapshot.error}'));
          }

          final messages = snapshot.data ?? [];
          return Chat(
            messages: messages,
            onSendPressed: _onSendPressed,
            user: _user,
          );
        },
      ),
    );
  }
}