import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:provider/provider.dart';
import 'package:walkwithwoofs/main.dart';
import 'package:walkwithwoofs/views/calendar.dart';
import 'package:walkwithwoofs/views/maps.dart';
import 'package:walkwithwoofs/views/review.dart';
import 'package:walkwithwoofs/views/walker_review.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  GoogleMapController? _mapController;
  Position? _currentPosition;
  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging.instance;
  String? walkerId;
  bool isWalker = false;

  static const LatLng _fatecIpiranga = LatLng(-23.588133, -46.633857);

  @override
  void initState() {
    super.initState();
    _checkLocationPermission();
    _setupFirebaseMessaging();
    _fetchWalkerId();
  }

  Future<void> _fetchWalkerId() async {
    final User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      try {
        final DocumentSnapshot docSnapshot = await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .get();

        if (docSnapshot.exists) {
          final data = docSnapshot.data() as Map<String, dynamic>;
          setState(() {
            isWalker = data['isWalker'] ?? false;
            walkerId = isWalker ? user.uid : null;
          });
        }
      } catch (e) {
        print(e);
      }
    }
  }

  Future<void> _setupFirebaseMessaging() async {
    await _firebaseMessaging.requestPermission();

    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      print('Mensagem recebida em primeiro plano: ${message.data}');

      if (message.notification != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(message.notification?.title ?? 'Nova Mensagem'),
            duration: Duration(seconds: 3),
          ),
        );
      }
    });
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      print('Mensagem: ${message.data}');
      Navigator.pushNamed(
        context,
        '/chat',
        arguments: message.data['chat_id'] ?? '',
      );
    });
  }

  Future<void> _checkLocationPermission() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      // Voltar aqui quando quiser fazer lógica
      return;
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return;
      }
    }

    _startTracking();
  }

  void _startTracking() {
    Geolocator.getPositionStream(
      locationSettings: LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 10,
      ),
    ).listen((Position position) {
      setState(() {
        _currentPosition = position;
        _mapController?.animateCamera(
          CameraUpdate.newLatLng(
            LatLng(position.latitude, position.longitude),
          ),
        );
      });
    });
  }

  Widget _buildMap() {
    return GoogleMap(
      onMapCreated: (GoogleMapController controller) {
        _mapController = controller;
        if (_currentPosition == null) {
          _mapController?.animateCamera(
            CameraUpdate.newLatLng(_fatecIpiranga),
          );
        } else {
          _mapController?.animateCamera(
            CameraUpdate.newLatLng(
              LatLng(_currentPosition!.latitude, _currentPosition!.longitude),
            ),
          );
        }
      },
      initialCameraPosition: CameraPosition(
        target: _currentPosition == null
            ? _fatecIpiranga
            : LatLng(_currentPosition!.latitude, _currentPosition!.longitude),
        zoom: 15.0,
      ),
      myLocationEnabled: true,
      myLocationButtonEnabled: true,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.logout),
          onPressed: () async {
            await FirebaseAuth.instance.signOut();
            Navigator.pushNamedAndRemoveUntil(
                context, '/login', (route) => false);
          },
        ),
        title: Text(
          'WalkWithWoofs',
          style: TextStyle(
            fontWeight: FontWeight.bold, 
          )  
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.account_circle),
            onPressed: () {
              Navigator.pushNamed(context, '/profile');
            },
          ),
          IconButton(
            icon: Icon(Icons.history),
            onPressed: () {
              // Placeholder rotas
            },
          ),
          Consumer<ThemeProvider>(
            builder: (context, themeProvider, child) {
              return IconButton(
                icon: Icon(
                  themeProvider.themeMode == ThemeMode.dark
                      ? Icons.wb_sunny
                      : Icons.nightlight_round,
                ),
                onPressed: () {
                  themeProvider
                      .toggleTheme(themeProvider.themeMode == ThemeMode.light);
                },
              );
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Container(
              color: Colors.orange,
              padding: EdgeInsets.all(20.0),
              child: Text(
                'Ad',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
            ),
            SizedBox(height: 20.0),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.0),
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: TextField(
                      decoration: InputDecoration(
                        labelText: 'Traçar rota de hoje',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  IconButton(
                    icon: Icon(Icons.search),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => MapPage()),
                      );
                    },
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20.0),
                    child: ElevatedButton(
                      child: Text('OLHA O CARRO DO LEITE'),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => CalendarPage()),
                        );
                      },
                    ),
                  ),
                  IconButton(
                    icon: Icon(Icons.rate_review),
                    onPressed: () {
                      if (!isWalker) {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ReviewPage(
                                walkerId: 'pPch8rNobtMNDrDD55DSU2DLUIB2'),
                          ),
                        );
                      } else {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => WalkerReviewPage(),
                          ),
                        );
                      }
                    },
                  )
                ],
              ),
            ),
            SizedBox(height: 20.0),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.0),
              child: ElevatedButton(
                child: Text('Abrir Chat'),
                onPressed: () {
                  Navigator.pushNamed(
                    context,
                    '/chat',
                    arguments: '1',
                  );
                },
              ),
            ),
            IconButton(
              icon: Icon(Icons.star),
              onPressed: () {
                Navigator.pushNamed(context, '/challenges');
              },
            ),
            SizedBox(height: 20.0),
            if(isWalker == false)
              Container(
                height: 300.0,
                child: _buildMap(),
              ),
            SizedBox(height: 20.0),
            if(isWalker == false)
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.0),
                child: Wrap(
                  spacing: 10.0,
                  runSpacing: 10.0,
                  children: List.generate(8, (index) {
                    return Consumer<ThemeProvider>(
                      builder: (context, themeProvider, child) {
                        return CircleAvatar(
                          radius: 40.0,
                          backgroundImage: AssetImage(
                            themeProvider.themeMode == ThemeMode.dark
                                ? 'lib/assets/logo_dark.png'
                                : 'lib/assets/logo.png',
                          ),
                        );
                      },
                    );
                  }),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
