import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:walkwithwoofs/controllers/auth_controller.dart';
import 'package:walkwithwoofs/main.dart';

class LoginPage extends StatelessWidget {
  final AuthController _authController = AuthController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        actions: [
          Consumer<ThemeProvider>(
            builder: (context, themeProvider, child) {
              return IconButton(
                icon: Icon(
                  themeProvider.themeMode == ThemeMode.dark
                      ? Icons.wb_sunny
                      : Icons.nightlight_round,
                ),
                onPressed: () {
                  themeProvider.toggleTheme(themeProvider.themeMode == ThemeMode.light);
                },
              );
            },
          )
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20.0),
        child: LoginForm(authController: _authController),
      ),
    );
  }
}

class LoginForm extends StatefulWidget {
  final AuthController authController;

  const LoginForm({Key? key, required this.authController}) : super(key: key);

  @override
  _LoginFormState createState() => _LoginFormState();
}

class _LoginFormState extends State<LoginForm> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  late String _email, _password;

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Consumer<ThemeProvider>(
            builder: (context, themeProvider, child){
              return Image.asset(
                themeProvider.themeMode == ThemeMode.dark
                ? 'lib/assets/logo_dark.png'
                : 'lib/assets/logo.png',
                height: 200,
              );
            },
          ),
          SizedBox(height: 20.0),
          TextFormField(
            decoration: InputDecoration(
              labelText: 'Email',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10.0)
              )            ),
            validator: (input) {
              if (input == null || input.isEmpty) {
                return 'Digite o seu email';
              }
              return null;
            },
            onSaved: (input) => _email = input!,
          ),
          SizedBox(height: 15.0),
          TextFormField(
            decoration: InputDecoration(
              labelText: 'Senha',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10.0)
              )
            ),
            validator: (input) {
              if (input == null || input.isEmpty) {
                return 'Digite a senha';
              }
              return null;
            },
            obscureText: true,
            onSaved: (input) => _password = input!,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              TextButton(
                onPressed: () {
                  Navigator.pushNamed(context, '/forgotpass');
                },
                child: Text(
                  'Esqueci minha senha',
                  style: TextStyle(color: Colors.red),
                ),
              ),
            ]
          ),
          Consumer<ThemeProvider>(
            builder: (context, themeProvider, child){
              return ElevatedButton(
                onPressed: _signInWithEmailAndPassword,
                style: ElevatedButton.styleFrom(
                  backgroundColor: themeProvider.themeMode == ThemeMode.dark
                  ? Colors.lightBlue[900]
                  : Colors.orange,
                  foregroundColor: Colors.black,
                ),
                child: Text('Login'),
              );
            },
          ),

          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('Ainda não é cadastrado com a gente?'),
              TextButton(
                onPressed: () {
                  Navigator.pushNamed(context, '/signup');
                },
                child: Text(
                  'Clique aqui',
                  style: TextStyle(color: Colors.red)
                ),
              ),
            ]
          ),
        ],
      ),
    );
  }

  void _signInWithEmailAndPassword() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      try {
        await widget.authController.signInWithEmailAndPassword(_email, _password);
        Navigator.pushReplacementNamed(context, '/home');
      } on FirebaseAuthException catch (e) {
        if (e.code == 'user-not-found') {
          _showErrorDialog('Usuário não encontrado na base de dados.');
        } else if (e.code == 'wrong-password') {
          _showErrorDialog('Senha Incorreta!');
        } else {
          _showErrorDialog('Erro: ${e.message}');
        }
      } catch (e) {
        _showErrorDialog('Erro: ${e.toString()}');
      }
    }
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Erro'),
          content: Text(message),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }
}
