import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:provider/provider.dart';
import 'package:walkwithwoofs/controllers/auth_controller.dart';
import 'package:walkwithwoofs/main.dart';
import 'package:intl/intl.dart';

class RegisterPage extends StatelessWidget {
  final AuthController _authController = AuthController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Cadastro',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.blue,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20.0),
        child: RegisterForm(authController: _authController),
      ),
    );
  }
}

class RegisterForm extends StatefulWidget {
  final AuthController authController;

  const RegisterForm({Key? key, required this.authController}) : super(key: key);

  @override
  _RegisterFormState createState() => _RegisterFormState();
}

class _RegisterFormState extends State<RegisterForm> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  late String _email;
  late String _password;
  late String _confirmPassword;
  late String _fullName;
  late String _phoneNumber;
  late String _birthDate;
  late String _profileImageUrl;
  bool _isWalker = false;

  final TextEditingController _birthDateController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _birthDateController.addListener(() {
      final text = _birthDateController.text;
      if (text.length == 2 || text.length == 5) {
        _birthDateController.text = '$text/';
        _birthDateController.selection = TextSelection.fromPosition(
          TextPosition(offset: _birthDateController.text.length),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          TextFormField(
            decoration: InputDecoration(
              labelText: 'Email',
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10.0)
              ),
            ),
            validator: (input) => input == null || input.isEmpty
                ? 'Digite o seu email'
                : null,
            onSaved: (input) => _email = input!,
          ),
          SizedBox(height: 15.0),
          TextFormField(
            decoration: InputDecoration(
              labelText: 'Nome Completo',
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10.0)
              ),
            ),
            validator: (input) => input == null || input.isEmpty
                ? 'Digite o seu nome completo'
                : null,
            onSaved: (input) => _fullName = input!,
          ),
          SizedBox(height: 15.0),
          TextFormField(
            decoration: InputDecoration(
              labelText: 'Número de Telefone',
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10.0)
              ),
            ),
            validator: (input) => input == null || input.isEmpty
                ? 'Digite o seu número de telefone'
                : null,
            onSaved: (input) => _phoneNumber = input!,
          ),
          SizedBox(height: 15.0),
          TextFormField(
            controller: _birthDateController,
            decoration: InputDecoration(
              labelText: 'Data de Nascimento DD/MM/AAAA',
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10.0)
              ),
            ),
            keyboardType: TextInputType.number,
            validator: (input) {
              if (input == null || input.isEmpty) {
                return 'Digite a sua data de nascimento';
              }
              try {
                DateFormat('dd/MM/yyyy').parseStrict(input);
              } catch (e) {
                return 'Data inválida. Use o formato DD/MM/AAAA.';
              }
              return null;
            },
            onSaved: (input) => _birthDate = input!,
          ),
          SizedBox(height: 15.0),
          TextFormField(
            controller: _passwordController,
            decoration: InputDecoration(
              labelText: 'Senha',
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10.0)
              ),
            ),
            validator: (input) => input == null || input.isEmpty
                ? 'Digite a senha'
                : null,
            obscureText: true,
            onSaved: (input) => _password = input!,
          ),
          SizedBox(height: 15.0),
          TextFormField(
            controller: _confirmPasswordController,
            decoration: InputDecoration(
              labelText: 'Confirme a Senha',
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10.0)
              ),
            ),
            validator: (input) {
              if (input == null || input.isEmpty) {
                return 'Confirme a senha';
              } else if (input != _passwordController.text) {
                return 'As senhas não coincidem';
              }
              return null;
            },
            obscureText: true,
            onSaved: (input) => _confirmPassword = input!,
          ),
          CheckboxListTile(
            title: Text('Sou Passeador'),
            value: _isWalker,
            onChanged: (bool? value) {
              setState(() {
                _isWalker = value!;
              });
            },
          ),
          Consumer<ThemeProvider>(
            builder: (context, themeProvider, child) {
              return ElevatedButton(
                onPressed: _registerWithEmailAndPassword,
                style: ElevatedButton.styleFrom(
                  backgroundColor: themeProvider.themeMode == ThemeMode.dark
                      ? Colors.lightBlue[900]
                      : Colors.orange,
                  foregroundColor: Colors.black,
                ),
                child: Text('Cadastrar'),
              );
            },
          ),
          SizedBox(height: 30.0),
          Center(child: Text('Já possui um cadastro?')),
          TextButton(
            onPressed: () {
              Navigator.pushReplacementNamed(context, '/login');
            },
            child: Text(
                'Clique aqui',
                style: TextStyle(color: Colors.red)
            ),
          ),
        ],
      ),
    );
  }

  void _registerWithEmailAndPassword() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      try {
        await widget.authController.signUpWithEmailAndPassword(
          _email,
          _password,
          _fullName,
          _phoneNumber,
          _birthDate,
          _isWalker,
          _profileImageUrl = '',
        );
        Navigator.pushNamed(context, '/login');
      } on FirebaseAuthException catch (e) {
        String message = '';
        switch (e.code) {
          case 'email-already-in-use':
            message = 'Este email já está em uso.';
            break;
          case 'weak-password':
            message = 'A senha é muito fraca, pelo menos 6 caracteres.';
            break;
          default:
            message = 'Erro: ${e.message}';
        }
        _showErrorDialog(message);
      } catch (e) {
        _showErrorDialog('Erro: ${e.toString()}');
      }
    }
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Erro'),
          content: Text(message),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }
}
