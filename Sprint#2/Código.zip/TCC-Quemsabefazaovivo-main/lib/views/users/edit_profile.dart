import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:walkwithwoofs/controllers/auth_controller.dart';
import 'package:walkwithwoofs/main.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class EditProfilePage extends StatefulWidget {

  @override
  _EditProfilePageState createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  final _formKey = GlobalKey<FormState>();
  final AuthController authController = AuthController();
  
  final TextEditingController _birthDateController = TextEditingController();
  final TextEditingController _fullNameController = TextEditingController();
  final TextEditingController _phoneNumberController = TextEditingController();

  bool? _isWalker;
  User? _user;

  @override
  void initState() {
    super.initState();
    _getUser();
    _getUserNameFromFirestore();
    _birthDateController.addListener(() {
      final text = _birthDateController.text;
      if (text.length == 2 || text.length == 5) {
        _birthDateController.text = '$text/';
        _birthDateController.selection = TextSelection.fromPosition(
          TextPosition(offset: _birthDateController.text.length),
        );
      }
    });
  }

  void _getUser() {
    _user = FirebaseAuth.instance.currentUser;
    setState(() {});
  }

  void _getUserNameFromFirestore() async {
    if (_user != null) {
      var doc = await FirebaseFirestore.instance
          .collection('users')
          .doc(_user!.uid)
          .get();
      if (doc.exists) {
        setState(() {
          _fullNameController.text = doc['fullName'] ?? '';
          _birthDateController.text = doc['birthDate'] ?? '';
          _phoneNumberController.text = doc['phoneNumber'] ?? '';
          _isWalker = doc['isWalker'] ?? false;
        });
      }
    }
  }

  void _updateProfile() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      try {
        await FirebaseFirestore.instance
            .collection('users')
            .doc(_user!.uid)
            .update({
          'fullName': _fullNameController.text,
          'phoneNumber': _phoneNumberController.text,
          'birthDate': _birthDateController.text,
          'isWalker': _isWalker,
        });
        Navigator.pop(context, true);
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro ao atualizar perfil: $e')),
        );
      }
    }
  }

  void _deleteAccount(User? user) async {
    if (user != null) {
      await authController.deleteAccount(user);
    }
    
  }

  void _showDeleteDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Excluir conta'),
          content: Text(
            'Tem certeza que deseja excluir sua conta? Essa ação será irreversível!'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Não'),
            ),
            TextButton(
              onPressed: () {
                _deleteAccount(_user);
                Navigator.pushNamedAndRemoveUntil(
                  context, '/login', (route) => false);
              },
              child: Text('Sim'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Editar Perfil',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.blue,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextFormField(
                controller: _fullNameController,
                decoration: InputDecoration(
                    labelText: 'Nome Completo',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    )),
                validator: (input) => input == null || input.isEmpty
                    ? 'Digite o seu nome completo'
                    : null,
                onSaved: (input) => _fullNameController.text = input!,
              ),
              SizedBox(height: 15.0),
              TextFormField(
                controller: _phoneNumberController,
                decoration: InputDecoration(
                  labelText: 'Número de Telefone',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0)),
                ),
                validator: (input) => input == null || input.isEmpty
                    ? 'Digite o seu número de telefone'
                    : null,
                onSaved: (input) => _phoneNumberController.text = input!,
              ),
              SizedBox(height: 15.0),
              TextFormField(
                controller: _birthDateController,
                decoration: InputDecoration(
                  labelText: 'Data de Nascimento DD/MM/AAAA',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0)),
                ),
                keyboardType: TextInputType.number,
                validator: (input) {
                  if (input == null || input.isEmpty) {
                    return 'Digite a sua data de nascimento';
                  }
                  try {
                    DateFormat('dd/MM/yyyy').parseStrict(input);
                  } catch (e) {
                    return 'Data inválida. Use o formato DD/MM/AAAA.';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20.0),
              Consumer<ThemeProvider>(
                builder: (context, themeProvider, child) {
                  return ElevatedButton(
                    onPressed: _updateProfile,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: themeProvider.themeMode == ThemeMode.dark
                          ? Colors.lightBlue[900]
                          : Colors.orange,
                      foregroundColor: Colors.black,
                    ),
                    child: Text('Salvar Alterações'),
                  );
                },
              ),
              SizedBox(height: 20.0),
              ElevatedButton(
                onPressed: _showDeleteDialog,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red,
                  foregroundColor: Colors.black,
                ),
                child: Text(
                  'Excluir conta', 
                  style: TextStyle(
                    fontWeight: FontWeight.bold
                  ),
                )
              ),
            ],
          ),
        ),
      ),
    );
  }
}
