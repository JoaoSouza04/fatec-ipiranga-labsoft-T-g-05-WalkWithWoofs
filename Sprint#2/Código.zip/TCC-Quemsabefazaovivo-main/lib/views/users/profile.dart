import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:walkwithwoofs/controllers/auth_controller.dart';
import 'package:walkwithwoofs/main.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'dart:io';

import 'package:walkwithwoofs/views/users/edit_profile.dart';

class ProfilePage extends StatelessWidget {
  final AuthController _authController = AuthController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Perfil',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: ProfileView(authController: _authController),
      ),
    );
  }
}

class ProfileView extends StatefulWidget {
  final AuthController authController;

  const ProfileView({Key? key, required this.authController}) : super(key: key);

  @override
  _ProfileViewState createState() => _ProfileViewState();
}

class _ProfileViewState extends State<ProfileView> {
  User? _user;
  String _displayName = "Carregando nome...";
  late String _birthDate = "Carregando data...";
  late String _phoneNumber = "Carregando telefone...";
  String _profileImageUrl = '';
  bool? _isWalker;

  @override
  void initState() {
    super.initState();
    _getUser();
    _getUserFromFirestore();
  }

  void _getUser() {
    User? user = FirebaseAuth.instance.currentUser;
    setState(() {
      _user = user;
    });
  }

  void _getUserFromFirestore() async {
    if (_user != null) {
      var doc = await FirebaseFirestore.instance
          .collection('users')
          .doc(_user!.uid)
          .get();
      if (doc.exists) {
        setState(() {
          _displayName = doc['fullName'] ?? 'Nome não disponivel';
          _birthDate = doc['birthDate'] ?? 'Data de nascimento não disponível';
          _phoneNumber = doc['phoneNumber'] ?? 'Telefone não disponível';
          _isWalker = doc['isWalker'] ?? false;
          _profileImageUrl = doc['profileImageUrl'] ?? '';
        });
      } else {
        setState(() {
          _displayName = 'Nome nao disponivel.';
          _isWalker = false;
        });
      }
    }
  }

  void _navigateToEditProfile() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => EditProfilePage()),
    );

    if (result == true) {
      _getUserFromFirestore();
    }
  }

  Future<void> _pickAndUploadImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      File file = File(pickedFile.path);
      try{
        final storageRef = FirebaseStorage.instance.ref().child('profile_images')
            .child('${_user!.uid}.jpg');
        await storageRef.putFile(file);
        String downloadUrl = await storageRef.getDownloadURL();

        await FirebaseFirestore.instance.collection('users').doc(_user!.uid).update({
          'profileImageUrl': downloadUrl,
        });

        setState(() {
          _profileImageUrl = downloadUrl;
        });
      } catch (e) {
        print(e);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Stack(
          alignment: Alignment.center,
          children: [
            Container(
              height: 200,
              width: 500,
            ),
            Consumer<ThemeProvider>(builder: (context, themeProvider, child) {
              return CircleAvatar(
                radius: 90.0,
                backgroundImage:  _profileImageUrl.isNotEmpty
                    ? NetworkImage(_profileImageUrl)
                    : AssetImage(
                  themeProvider.themeMode == ThemeMode.dark
                      ? 'lib/assets/logo_dark.png'
                      : 'lib/assets/logo.png',
                ),
              );
            }),
            Positioned(
              top: 155,
              right: 80,
              child: IconButton(
                icon: Icon(Icons.camera_enhance_rounded,
                size: 35.0),
                onPressed: _pickAndUploadImage,
              ),
            )
          ],
        ),
        SizedBox(
          height: 20.0,
        ),
        Center(
          child: Text(
            _displayName,
            style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
          ),
        ),
        Center(
          child: Text(
            _user != null ? "Email: ${_user!.email}" : "Carregando email...",
          ),
        ),
        SizedBox(
          height: 20.0,
        ),
        Consumer<ThemeProvider>(
          builder: (context, themeProvider, child) {
            return Container(
              height: 150,
              padding: const EdgeInsets.all(10.0),
              decoration: BoxDecoration(
                color: themeProvider.themeMode == ThemeMode.dark
                  ? Colors.lightBlue[900]
                  : Colors.orange,
                borderRadius: BorderRadius.circular(16.0)
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Row(
                    children: [
                      Icon(Icons.calendar_today),
                      SizedBox(width: 10), 
                      Text("${_birthDate}")
                    ],
                  ),
                  Row(
                    children: [
                      Icon(Icons.phone),
                      SizedBox(width: 10),
                      Text("${_phoneNumber}")
                    ],
                  ),
                  Row(
                    children: [
                      Icon(Icons.directions_walk),
                      SizedBox(width: 10),
                      if(_isWalker== false)
                        Text('Você não é um passeador!')
                      else
                        Text('Você é um passeador!')
                    ],
                  ),
                ]
              ),
            );
          }
        ),
        SizedBox(height: 70.0),
        Row(
          mainAxisAlignment: _isWalker == false
              ? MainAxisAlignment.spaceAround
              : MainAxisAlignment.center,
          children: [
            Consumer<ThemeProvider>(
              builder: (context, themeProvider, child) {
                return ElevatedButton(
                    onPressed: _navigateToEditProfile,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: themeProvider.themeMode == ThemeMode.dark
                        ? Colors.lightBlue[900]
                        : Colors.orange,
                      foregroundColor: Colors.black
                    ),
                    child: Text('Alterar Cadastro'));
              },
            ),
            if (_isWalker == false)
              Consumer<ThemeProvider>(
                builder: (context, themeProvider, child) {
                  return ElevatedButton(
                      onPressed: () {
                        Navigator.pushNamed(context, '/pets');
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor:
                          themeProvider.themeMode == ThemeMode.dark
                            ? Colors.lightBlue[900]
                            : Colors.orange,
                        foregroundColor: Colors.black,
                      ),
                      child: Text('Informações do pet'));
                },
              ),
          ],
        ),
      ],
    );
  }
}
