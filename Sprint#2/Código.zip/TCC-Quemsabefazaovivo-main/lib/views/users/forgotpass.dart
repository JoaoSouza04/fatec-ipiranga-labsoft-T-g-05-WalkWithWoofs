import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:walkwithwoofs/controllers/auth_controller.dart';
import 'package:walkwithwoofs/main.dart';

class ForgotpassPage extends StatelessWidget {
  final AuthController _authController = AuthController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text(
            'Redefinir a senha',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          centerTitle: true,
        ),
      
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(20.0),
          child: ForgotpassForm(authController: _authController),
        ),
    );
  }
}

class ForgotpassForm extends StatefulWidget {
  final AuthController authController;

  const ForgotpassForm({Key? key, required this.authController}) : super(key: key);

  @override
  _ForgotpassFormState createState() => _ForgotpassFormState();

}

class _ForgotpassFormState extends State<ForgotpassForm> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  
  late String _email;

  @override
  Widget build(BuildContext context) {
    return Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Consumer<ThemeProvider>(
              builder: (context, themeProvider, child) {
                return Image.asset(
                  themeProvider.themeMode == ThemeMode.dark
                      ? 'lib/assets/logo_dark.png'
                      : 'lib/assets/logo.png',
                  height: 200,
                );
              },
            ),
            SizedBox(height: 15.0),
            TextFormField(
              decoration: InputDecoration(
                labelText: 'Email',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10.0),
                )
              ),
              validator: (input) {
                if (input == null || input.isEmpty) {
                  return 'Digite o seu email para a recuperação';
                }
                return null;
              },
              onSaved: (input) => _email = input!,
            ),
            SizedBox(height: 15.0),
            Consumer<ThemeProvider>(
              builder: (context, themeProvider, child){
                return ElevatedButton(
                  onPressed: () {
                    _sendPasswordResetEmail();
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: themeProvider.themeMode == ThemeMode.dark
                        ? Colors.lightBlue[900]
                        : Colors.orange,
                    foregroundColor: Colors.black,
                  ),
                  child: Text('Enviar link de recuperação'),
                );
              },
            ),

          ],
        )
    );
  }


  void _sendPasswordResetEmail() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      try {
        await widget.authController.sendPasswordResetEmail(_email);
        Navigator.pop(context);
      } 
      catch (e) {
        _showErrorDialog('Erro: ${e.toString()}');
      }
    }
  }

  void _showErrorDialog(String message) {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Erro'),
            content: Text(message),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('OK'),
              ),
            ],
          );
        }
    );
  }
}