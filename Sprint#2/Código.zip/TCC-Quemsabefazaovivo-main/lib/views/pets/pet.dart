import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:walkwithwoofs/main.dart';
import 'package:walkwithwoofs/views/pets/edit_pet.dart';
import 'package:walkwithwoofs/views/pets/pet_signup.dart';

class PetPage extends StatelessWidget {
  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Meu Pet',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: PetPageView(),
      ),
    );
  }
}

class PetPageView extends StatefulWidget {
  const PetPageView({Key? key}) : super(key: key);

  @override
  State<PetPageView> createState() => _PetPageViewState();
}

class _PetPageViewState extends State<PetPageView> {
  User? _user;
  String _name = "Não Informado";
  String _breed = "Carregando...";
  String _size = "Carregando...";
  double _weight = 0;
  bool _petExists = true;
  bool _isWalker = false;

  @override
  void initState() {
    super.initState();
    _getUser();
    _verifyUserPet();
  }

  void _getUser() {
    User? user = FirebaseAuth.instance.currentUser;
    setState(() {
      _user = user;
    });
  }
  
  void _navigateToPage(String action) async {
    bool? result = false;
    switch(action) {
      case 'create':
        result = await Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => PetRegisterPage()),
        );
      case 'update':
        result = await Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => EditPetPage()),
        );
    }

    if (result == true) {
      _verifyUserPet();
    }
  }

  void _verifyUserPet() async {
    final doc = await FirebaseFirestore.instance.collection('users').doc(_user!.uid).get();
    final petID;

    if(doc.exists) {
      final petData = doc['pet'] as Map<String, dynamic>?;
      if(doc['isWalker'] == true) {
        setState(() {
          _isWalker == true;
        });
      }
      if(petData != null && petData.isNotEmpty) {
        setState(() {
          _petExists = true;
        });
        petID = doc['pet']['petID'];
        _getPetFromFirestore(petID.path);
      }
      else {
        setState(() {
          _petExists = false;
        });
      }
    }
  }

  void _getPetFromFirestore(String petID) async {
    final doc = await FirebaseFirestore.instance.doc(petID).get();
    
    if(doc.exists) {
      setState(() {
        _name = doc['name'] ?? "Sem dados...";
        _breed = doc['breed'] ?? "Sem dados...";
        _size = doc['size'] ?? "Sem dados...";
        _weight = doc['weight'] ?? "Sem dados...";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Consumer<ThemeProvider>(
          builder: (context, themeProvider, child){
            return Image.asset(
              themeProvider.themeMode == ThemeMode.dark
              ? 'lib/assets/logo_dark.png'
              : 'lib/assets/logo.png',
              height: 200,
            );
          },
        ),
        SizedBox(
          height: 20.0,
        ),
        Center(
          child: Text(
            _name,
            style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
          ),
        ),
        SizedBox(
          height: 20.0,
        ),
        Consumer<ThemeProvider>(
          builder: (context, themeProvider, child) {
            return Container(
              height: 150,
              padding: const EdgeInsets.all(10.0),
              decoration: BoxDecoration(
                color: themeProvider.themeMode == ThemeMode.dark
                  ? Colors.lightBlue[900]
                  : Colors.orange,
                borderRadius: BorderRadius.circular(16.0)
              ),
              child: 
                (_petExists == false && _isWalker == false) 
                ? Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.pets),
                    SizedBox(width: 10),
                    Text('Você ainda não registrou seu cachorro!')
                  ],
                )
              : Column(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Row(
                    children: [
                      Icon(Icons.pets),
                      SizedBox(width: 10), 
                      Text("Raça: ${_breed}")
                    ],
                  ),
                  Row(
                    children: [
                      Icon(Icons.straighten),
                      SizedBox(width: 10),
                      Text("Tamanho: ${_size}")
                    ],
                  ),
                  Row(
                    children: [
                      Icon(Icons.fitness_center),
                      SizedBox(width: 10),
                      Text("Peso: ${_weight}")
                    ],
                  ),
                ]
              ),
            );
          }
        ),
        SizedBox(height: 70.0),
        Consumer<ThemeProvider>(
          builder: (context, themeProvider, child) {
            return ElevatedButton(
              onPressed: () {
                _petExists 
                ? _navigateToPage('update')
                : _navigateToPage('create');
              },
              style: ElevatedButton.styleFrom(
                backgroundColor:
                  themeProvider.themeMode == ThemeMode.dark
                    ? Colors.lightBlue[900]
                    : Colors.orange,
                foregroundColor: Colors.black,
              ),
              child: Text(_petExists ? 'Atualizar Informações' : 'Cadastrar pet')
            );
          },
        )
      ],
    );
  }
}