import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:walkwithwoofs/controllers/pet_controller.dart';
import 'package:walkwithwoofs/main.dart';

class PetRegisterPage extends StatelessWidget {
  
  final PetController _petController = PetController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Cadastro de Pet',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.blue,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20.0),
        child: PetRegisterForm(petController: _petController),
      ),
    );
  }
}

class PetRegisterForm extends StatefulWidget {
  final PetController petController;

  const PetRegisterForm({Key? key, required this.petController}) : super(key: key);

  @override
  State<PetRegisterForm> createState() => _PetRegisterFormState();
}

class _PetRegisterFormState extends State<PetRegisterForm> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  User? _user;
  late String _name;
  late String _breed;
  late String _size;
  late double _weight;
  

  @override
  void initState() {
    super.initState();
    _getUser();
  }

  void _getUser() {
    User? user = FirebaseAuth.instance.currentUser;
    setState(() {
      _user = user;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          SizedBox(height: 15.0),
          TextFormField(
            decoration: InputDecoration(
              labelText: 'Nome',
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10.0)
              ),
            ),
            validator: (input) => input == null || input.isEmpty
                ? 'Digite o nome do seu cachorro'
                : null,
            onSaved: (input) => _name = input!,
          ),
          SizedBox(height: 15.0),
          TextFormField(
            decoration: InputDecoration(
              labelText: 'Raça',
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10.0)
              ),
            ),
            validator: (input) => input == null || input.isEmpty
                ? 'Digite a raça do seu cachorro'
                : null,
            onSaved: (input) => _breed = input!,
          ),
          SizedBox(height: 15.0),
          TextFormField(
            decoration: InputDecoration(
              labelText: 'Porte',
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10.0)
              ),
            ),
            validator: (input) => input == null || input.isEmpty
                ? 'Digite o porte do seu cachorro'
                : null,
            onSaved: (input) => _size = input!,
          ),
          SizedBox(height: 15.0),
          TextFormField(
            decoration: InputDecoration(
              labelText: 'Peso',
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10.0)
              ),
            ),
            keyboardType: TextInputType.number,
            validator: (input) => input == null || input.isEmpty
                ? 'Digite o peso do seu cachorro'
                : null,
            onSaved: (input) => _weight = double.parse(input!),
          ),
          SizedBox(height: 30.0),
          Consumer<ThemeProvider>(
            builder: (context, themeProvider, child) {
              return ElevatedButton(
                onPressed: _registerPet,
                style: ElevatedButton.styleFrom(
                  backgroundColor: themeProvider.themeMode == ThemeMode.dark
                      ? Colors.lightBlue[900]
                      : Colors.orange,
                  foregroundColor: Colors.black,
                ),
                child: Text('Cadastrar'),
              );
            },
          ),
        ],
      ),
    );
  }

  void _registerPet() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      try {
        await widget.petController.petSignUp(
          _name,
          _breed,
          _size,
          _weight,
          _user!.uid
        );
        Navigator.pop(context, true);
      } on FirebaseAuthException catch (e) {
        String message = '';
        _showErrorDialog(message);
      } catch (e) {
        _showErrorDialog('Erro: ${e.toString()}');
      }
    }
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Erro'),
          content: Text(message),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }
}
