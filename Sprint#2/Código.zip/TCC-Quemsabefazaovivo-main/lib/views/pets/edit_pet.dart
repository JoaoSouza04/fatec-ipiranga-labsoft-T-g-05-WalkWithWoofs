import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:walkwithwoofs/controllers/pet_controller.dart';
import 'package:walkwithwoofs/main.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class EditPetPage extends StatefulWidget {
  final PetController petController = PetController();
  
  @override
  _EditPetPageState createState() => _EditPetPageState();
}

class _EditPetPageState extends State<EditPetPage> {
  final _formKey = GlobalKey<FormState>();
  
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _breedController = TextEditingController();
  final TextEditingController _sizeController = TextEditingController();
  final TextEditingController _weightController = TextEditingController();

  User? _user;
  String? _petID;

  @override
  void initState() {
    super.initState();
    _getUser();
    _getPetFromFirestore();
  }

  void _getUser() {
    _user = FirebaseAuth.instance.currentUser;
    setState(() {});
  }

  void _getPetFromFirestore() async {
    if (_user != null) {
      final petID = await widget.petController.findPet(_user!.uid);
      final doc = await FirebaseFirestore.instance.collection('pets').doc(petID).get();
      
      String name = doc['name'];
      String breed = doc['breed'];
      String size = doc['size'];
      double weight = doc['weight'];

      if (petID.isNotEmpty) {
        _petID = petID;
        setState(() {
          _nameController.text = name ?? '';
          _breedController.text = breed ?? '';
          _sizeController.text = size ?? '';
          _weightController.text = weight.toString() ?? '';
        });
      }
    }
  }

  void _updatePet() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      try {
        await widget.petController.updatePet(
          _nameController.text, 
          _breedController.text, 
          _sizeController.text, 
          double.parse(_weightController.text), 
          _petID!
        );
        Navigator.pop(context, true);
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro ao atualizar perfil: $e')),
        );
      }
    }
  }
  void _deletePet(User? user) async {
    if (user != null) {
      await widget.petController.deletePet(user);
    }
    
  }

  void _showDeleteDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Excluir Pet'),
          content: Text(
            'Tem certeza que deseja excluir o registro do seu pet? Essa ação será irreversível!'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Não'),
            ),
            TextButton(
              onPressed: () {
                _deletePet(_user);
                Navigator.pushNamedAndRemoveUntil(
                  context, '/profile', (route) => false);
              },
              child: Text('Sim'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Editar Pet',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.blue,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextFormField(
                controller: _nameController,
                decoration: InputDecoration(
                    labelText: 'Nome',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    )),
                validator: (input) => input == null || input.isEmpty
                    ? 'Digite o nome do seu cachorro'
                    : null,
                onSaved: (input) => _nameController.text = input!,
              ),
              SizedBox(height: 15.0),
              TextFormField(
                controller: _breedController,
                decoration: InputDecoration(
                  labelText: 'Raça',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0)),
                ),
                validator: (input) => input == null || input.isEmpty
                    ? 'Digite a raça do seu cachorro'
                    : null,
                onSaved: (input) => _breedController.text = input!,
              ),
              SizedBox(height: 15.0),
              TextFormField(
                controller: _sizeController,
                decoration: InputDecoration(
                    labelText: 'Porte',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    )),
                validator: (input) => input == null || input.isEmpty
                    ? 'Digite o porte do seu cachorro'
                    : null,
                onSaved: (input) => _sizeController.text = input!,
              ),
              SizedBox(height: 15.0),
              TextFormField(
                controller: _weightController,
                decoration: InputDecoration(
                    labelText: 'Peso',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    )),
                validator: (input) => input == null || input.isEmpty
                    ? 'Digite o peso do seu cachorro'
                    : null,
                onSaved: (input) => _weightController.text = input!,
              ),
              SizedBox(height: 20.0),
              Consumer<ThemeProvider>(
                builder: (context, themeProvider, child) {
                  return ElevatedButton(
                    onPressed: _updatePet,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: themeProvider.themeMode == ThemeMode.dark
                          ? Colors.lightBlue[900]
                          : Colors.orange,
                      foregroundColor: Colors.black,
                    ),
                    child: Text('Salvar Alterações'),
                  );
                },
              ),
              SizedBox(height: 20.0),
              ElevatedButton(
                onPressed: _showDeleteDialog,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red,
                  foregroundColor: Colors.black,
                ),
                child: Text(
                  'Excluir seu pet', 
                  style: TextStyle(
                    fontWeight: FontWeight.bold
                  ),
                )
              ),
            ],
          ),
        ),
      ),
    );
  }
}
