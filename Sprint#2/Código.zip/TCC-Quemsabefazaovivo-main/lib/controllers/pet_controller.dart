import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class PetController {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> petSignUp(String name, String breed, 
    String size, double weight, String ownerID) async {
    try {
      final petRef = await _firestore.collection('pets').add({
        'breed': breed,
        'name': name,
        'size': size,
        'weight': weight
      });

      await _firestore.collection('users').doc(ownerID).update({
        'pet': {
          'petID': petRef,
        }
      });
    } catch (e) {
      throw e;
    }
  }
  
  Future<String> findPet(String userID) async {
    try {
      var doc = await _firestore.collection('users').doc(userID).get();
      final petData = doc['pet'];
      final petID = petData['petID'];
      return petID.id;
    } catch (e) {
      throw e;
    }
  }

  Future<void> updatePet(String name, String breed, String size, double weight, String petID) async {
    try {
      await _firestore.collection('pets').doc(petID).update({
          'name': name,
          'breed': breed,
          'size': size,
          'weight': weight,
        });
    } catch (e) {
      throw e;
    }
  }

  Future<void> deletePet(User user) async {
    try {
      var doc = await _firestore.collection('users').doc(user.uid).get();
      
      if(doc['isWalker'] == false) {
        final petData = doc['pet'];
        if(petData.isNotEmpty){
          final petID = petData['petID'];
          await _firestore.collection('pets').doc(petID.id).delete();
        }
      }

      await _firestore.collection('users').doc(user.uid).update({
        'pet': {}        
      });
    }
    catch (e) {
      throw e;
    }
  }
}