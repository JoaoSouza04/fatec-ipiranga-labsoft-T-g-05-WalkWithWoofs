import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AuthController {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> signInWithEmailAndPassword(String email, String password) async {
    try {
      await _auth.signInWithEmailAndPassword(email: email, password: password);
    } catch (e) {
      throw e;
    }
  }

  Future<void> signUpWithEmailAndPassword(String email, String password, String fullName,
      String phoneNumber, String birthDate, bool isWalker, String profileImageUrl) async {
    try {
      UserCredential userCredential = await _auth.createUserWithEmailAndPassword(email: email, password: password);

      await _firestore.collection('users').doc(userCredential.user!.uid).set({
        'fullName': fullName,
        'phoneNumber': phoneNumber,
        'birthDate': birthDate,
        'isWalker': isWalker,
        'email': email,
        'profileImageUrl': profileImageUrl,
      });
      if(isWalker == false) {
        await _firestore.collection('users').doc(userCredential.user!.uid).update({
        'pet': {}
      });
      }
    } catch (e) {
      throw e;
    }
  }

  Future<void> deleteAccount(User user) async {
    try {
      var doc = await _firestore.collection('users').doc(user.uid).get();
      
      if(doc['isWalker'] == false) {
        final petData = doc['pet'];
        if(petData.isNotEmpty){
          final petID = petData['petID'];
          await _firestore.collection('pets').doc(petID.id).delete();
        }
      }
      await _firestore.collection('users').doc(user.uid).delete();
      await user.delete();
    }
    catch (e) {
      throw e;
    }
  }

  Future<void> signOut() async {
    await _auth.signOut();
  }

  Future<void> sendPasswordResetEmail(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email);
    } catch (e) {
      throw e;
    }
  }
}