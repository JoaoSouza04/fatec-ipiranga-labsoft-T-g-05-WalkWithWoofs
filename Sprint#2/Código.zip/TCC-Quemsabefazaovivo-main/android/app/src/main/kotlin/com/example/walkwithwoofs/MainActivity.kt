package com.example.walkwithwoofs

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
